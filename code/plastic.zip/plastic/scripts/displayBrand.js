
function displayBrand(s)
{
    window.location.assign("listType.php?Type="+s);
    // alert(s);
}

function displayProduct(s)
{
    window.location.assign("listProduct.php?Product="+s);
    // alert(s);
}
