
function displayDetail(s)
{
    window.location.assign("detail.php?productName="+s);
    // alert(s);
}
