
<link rel="stylesheet" href="css/left.css">


<!------------------- topNavigation ----------------------->
				<div class="searchBox">
					<form action="">
						<strong class="searchTitle" style="display: block;">Products Search</strong>
						<input type="text" name="p_search" id="p_search">
						<input type="submit" value="Search" name="Search" id="Search">
					</form>
				</div>
<!------------------- sideNavigation ----------------------->
				
<div class="sideNav">
<?php
				//include_once'menu.php';
 ?>
</div>
<div class="leftSideInformation">
	<strong class="informationTitle">Dolphin Plastic Trading</strong>
	<address>
		155, Jalan Berjasa 7,<br>
		Taman Timur,<br>
		81000 Kulai ,<br>
		Johor, Malaysia. <br>

	</address>
	<div class="left-phone">
		<i class="material-icons iconBG">phone</i>
		<span class="telNum">+6016-7653800	</span>				
	</div>
	<div class="left-email">
		<i class="material-icons iconBG emailPosition">email</i>
		<a href="mailto:enquiry@dolphinplastic.com">
			
		enquiry@dolphinplastic.com</a>

	</div>
	<div class="left-whatsapp">
		<i class="fab fa-whatsapp-square whatsappBG"></i>
		<a href="https://web.whatsapp.com/send?phone=+60167653800" target="_blank">+60167653800</a>
	</div>
</div>