<link rel="stylesheet" href="css/footer.css">
<link rel="stylesheet" href="css/home.css">

<div class="footer-main-section">
	<div class="container">
			<section class="QuickLinks col-4">
				<ul>				
					<h2>QuickLinks</h2>	
					<li><a href="home.php">Home</a></li>
					<li><a href="aboutUs.php">About</a></li>					
			</section>
			<!-- <section class="Recent border col-3">
				<ul>
					<h2>Recent Post</h2>
					<li></li>
					<li></li>
					<li></li>
				</ul>
			</section> -->
			<section class="Contact col-4">
				<h2>Contact</h2>
				<?php echo include('footer.php')?>;
			</section>
		</div>
	</div>