
<link rel="stylesheet" href="css/footer.css">
<footer>
	<div class="footer-center">
		<div class="inner-left">
			<p>&copy;2017-2019 <span>Dolphin Plastic Trading</span> (JM0785222-H)        <span class="space">Visitors: 114545</span></p>
		</div>
		<div class="inner-right">
			<p>Powered by <a href="#">N.MY</a></p>
		</div>
	</div>

</footer>